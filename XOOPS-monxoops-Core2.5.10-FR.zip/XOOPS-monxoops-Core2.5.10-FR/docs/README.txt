XOOPS 2.5.10

The XOOPS Development Team is pleased to announce the release of XOOPS 2.5.10. This version
includes fixes and enhancements, security updates, PHP 7.3 and MySQL 8.0 compatibility.

Download XOOPS 2.5.10 from GitHub: https://github.com/XOOPS/XoopsCore25/releases

For full documentation on installing or upgrading XOOPS please see:
https://xoops.gitbook.io/xoops-install-upgrade/

How to contribute
-----------------------------------
Bug reports and feature requests: https://github.com/XOOPS/XoopsCore25/issues
Patch and enhancement: https://github.com/XOOPS/XoopsCore25/blob/master/CONTRIBUTING.md
Documentation: https://xoops.gitbook.io/xoops-documentation-process
Support Forums: https://xoops.org/modules/newbb/

XOOPS Development Team
2019
